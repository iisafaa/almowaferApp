import 'dart:js';

import 'package:flutter/material.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:almowafer/splash_screen/SplashScreen.dart';
import 'package:almowafer/login_screen/login.dart';

class IntroScreen extends StatelessWidget {
  IntroScreen({super.key});
  final List<PageViewModel> pages = [
    PageViewModel(
      title: ' مرحبًا بك في الموفر',
      decoration: const PageDecoration(
          titleTextStyle: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 30,
        color: Color(0xff52307E),
      )),
      body: 'تطبيق “الموفر” يساعدك في الحصول\n على أوفر المنتجات بأسهل طريقة.',
      image: Image.asset('asset/int.png'),
    ),
    PageViewModel(
      title: ' مرحبًا بك في الموفر',
      decoration: const PageDecoration(

          //imagePadding = const EdgeInsets.only(bottom: 24.0),
          titleTextStyle: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 30,
        color: Color(0xff52307E),
      )),
      body: 'وممكن تكون عضو في مجتمعنا\n        كمندوب توصيل.',
      image: Image.asset('asset/Intro.png'),
    ),
    PageViewModel(
      title: '',
      decoration: const PageDecoration(),
      body: 'خليك نبيه',
      footer: ElevatedButton(
        onPressed: (){},
        child: Text(
          "إبدأ",
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        style: ButtonStyle(
            elevation: MaterialStateProperty.all(5),
            backgroundColor: MaterialStateProperty.all(
                Color(0xff52307E)), //لون خلفيه البوتون
            padding: MaterialStateProperty.all((EdgeInsets.symmetric(
                horizontal: 70, vertical: 15))), // حجم البوتون
            shape: MaterialStateProperty.all(RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30)))),
      ),
      image: Image.asset(
        'asset/almowaerlogo.png',
      ),
    )
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.all(50),
        child: IntroductionScreen(
          //   هذي ميثود من مكتبه الانترودكشن سكرين
          pages: pages,
          dotsDecorator: const DotsDecorator(
              // تنسيق الدوائر الصغيرة
              size: Size((5), 5),
              color: Colors.grey,
              activeSize: Size.square(10),
              activeColor: Color(0xff52307E)),
          showDoneButton: true, // اذا سوينا ذا لازم نستدعي ودجيت دن كمان
          done: const Text("ابدأ",style: TextStyle(fontSize: 15 ,color: Color(0xffB767C6)),),
          showSkipButton: true,
          skip: const Text("تخطي",
              style: TextStyle(fontSize: 15, color: Color(0xffB767C6))),
          showNextButton: true,
          next: const Icon(
            Icons.arrow_forward,
            size: 20,
            color: Color(0xffB767C6),
          ),
          onDone: () => onDone(context),

        ),
      ),
    );
  }

  /*void onPressed(context) {
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => const loginScreen()));
  }*/

  void onDone(context) {
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => const loginScreen()));
  }
}
