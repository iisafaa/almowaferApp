import 'package:flutter/material.dart';

class loginScreen extends StatefulWidget {
  const loginScreen({super.key});

  @override
  State<loginScreen> createState() => _loginScreenState();
}

class _loginScreenState extends State<loginScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          //حطيت هذا لانه كان يجيني بوكس ايرور اصفر على تحت
          child: Padding(
            padding: const EdgeInsets.all(40),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Center(child: Image.asset('asset/almowaerlogo.png')),
                const SizedBox(
                  height: 30,
                ),
                const Text(
                  "تسجيل الدخول",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xff52307E),
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                TextFormField(
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                      label: const Text(
                        "ادخل البريد الالكتروني",
                        style: TextStyle(fontSize: 15),
                      ),
                      prefixIcon: Icon(
                        Icons.email,
                        color: Color(0xff52307E),
                        size: 25,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      )),
                ),
                SizedBox(
                  height: 20,
                ),

                TextFormField(
                  keyboardType: TextInputType.visiblePassword,
                  decoration: InputDecoration(
                      label: Text(
                        "ادخل كلمة المرور",
                        style: TextStyle(fontSize: 15),
                      ),
                      prefixIcon: Icon(
                        Icons.password,
                        color: Color(0xff52307E),
                        size: 25,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      )),
                ),

                SizedBox(
                  height: 20,
                ),
                Text("نسيت كلمة المرور ؟"),

                SizedBox(
                  height: 30,
                ),
               ElevatedButton(
                    onPressed: () {Navigator.of(context).pushNamed('login');},
                    child: Text(" تسجيل الدخول"),
                    style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all(Color(0xff52307E)),  //لون خلفيه البوتون
                       padding: MaterialStateProperty.all((EdgeInsets.symmetric(horizontal: 130,vertical: 15))), // حجم البوتون
                       shape: MaterialStateProperty.all(RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)))
                  )),
                SizedBox(
                  height: 15,
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                    children: [

                Text("اذا كنت لاتملك حسابًا "),

                // تسمح انه اذا ضغطنا على التكست يروح لصفحة الساين
                 GestureDetector(onTap :(){
                   Navigator.of(context).pushNamed('/login');
                 },
                  child: Text("اضغط هنا",style: TextStyle( color: Color(0xff52307E)),)),

                 Text(" لإنشاء حساب  ")
                ]
                ),
              ],
            ),
          ),
        ),
      ),
    );

  }
}
