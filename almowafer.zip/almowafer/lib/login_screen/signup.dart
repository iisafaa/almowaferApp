import 'package:flutter/material.dart';

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  bool? isCheked = false;   //سويته عشان الشيك بوكس

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset('asset/almowaerlogo.png'),
        centerTitle: true,
       // 17و 18 عشان نشيل الخلفيه
        backgroundColor: Colors.transparent,
        elevation: 0.0,


      ),
      body:
      Center(
        child: Padding(
          padding:EdgeInsets.all(40) ,
          child:
          Wrap(
            children:[ Column(

              mainAxisAlignment: MainAxisAlignment.spaceEvenly,

              children: [

                 Text(
                    "إنشاء حساب",
                    style: TextStyle(
                      color: Color(0xff52307E),
                      fontSize: 20,
                      fontWeight: FontWeight.bold
                    ),
                  ),

                SizedBox(
                  height: 20,
                ),

                TextFormField(
                  keyboardType: TextInputType.name,
                  decoration: InputDecoration(
                    label: Text(
                      "ادخل الاسم الكامل",
                      style: TextStyle(fontSize: 15),),
                    prefixIcon: Icon(
                    Icons.person,
                    color: Color(0xff52307E),
                    size: 25,
                  ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      )
                    ),
                ),

                SizedBox(
                  height: 20,
                ),

                TextFormField(
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                      label: Text(
                        "ادخل البريد الالكتروني",
                        style: TextStyle(fontSize: 15),),
                      prefixIcon: Icon(
                        Icons.email,
                        color: Color(0xff52307E),
                        size: 25,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      )
                  ),
                ),

                SizedBox(
                  height: 20,
                ),


                TextFormField(
                  keyboardType: TextInputType.name,
                  decoration: InputDecoration(
                      label: Text(
                        "ادخل رقم الهاتف المحمول",
                        style: TextStyle(fontSize: 15),),
                      prefixIcon: Icon(
                        Icons.phone,
                        color: Color(0xff52307E),
                        size: 25,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      )
                  ),
                ),

                SizedBox(
                  height: 20,
                ),

               TextFormField(
                  keyboardType: TextInputType.visiblePassword,
                  decoration: InputDecoration(
                      label: Text(
                        "ادخل كلمة المرور",
                        style: TextStyle(fontSize: 15),
                      ),
                      prefixIcon: Icon(
                        Icons.password,
                        color: Color(0xff52307E),
                        size: 25,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      )),
                ),

                SizedBox(
                  height: 30,
                ),
                ElevatedButton(
                    onPressed: () {Navigator.of(context).pushNamed('/home');},
                    child: Text("إنشاء حساب"),
                    style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all(Color(0xff52307E)),  //لون خلفيه البوتون
                        padding: MaterialStateProperty.all((EdgeInsets.symmetric(horizontal: 145,vertical: 15))), // حجم البوتون
                        shape: MaterialStateProperty.all(RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)))
                    )),

                SizedBox(
                  height: 10,
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children:[

                    Checkbox(
                      value: isCheked,
                      activeColor:Color(0xff52307E),
                      onChanged: (newBool){  //اذا سوا شيك الميثود هذا رح يتنفذ
                              setState(() {
                                isCheked=newBool;
                              });
                      },
                     ),
Text(" انشائك للحساب يعني انك توافق على شروط المستخدم وسياسة الخصوصية",style: TextStyle(
                        fontSize: 10
                    ),),


                  ],
                )

              ],
            ),],
          ),
        ),
      ),
    );
  }
}
