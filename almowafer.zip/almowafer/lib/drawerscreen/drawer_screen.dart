import 'package:flutter/material.dart';

class DrawerScreen extends StatefulWidget {
  const DrawerScreen({super.key});

  @override
  State<DrawerScreen> createState() => _DrawerScreenState();
}

class _DrawerScreenState extends State<DrawerScreen> {
  @override
  Widget build(BuildContext context) {
    return
    Drawer(
      child: ListView(
        children: [
          const UserAccountsDrawerHeader(
            currentAccountPicture: CircleAvatar(
              // هذا عشان نخلي الصورة تجي على دائرة

              backgroundImage: AssetImage(
                  //ما استخدمنا imagege.asset لانه الباكقرواند ستاتيك وهذا الاميج اسيت داينمك واستخدمنا الستاتيك منها الي هيا الاسيت اميج
                  'asset/almowaerlogo.png'),
            ),
            accountName: Text("Safaa Hasan"),
            accountEmail: Text("SafaaHasan@gmail.com"),
          ),
          ListTile(
            title: Text("الصفحة الرئيسية"),
            onTap: () {
              Navigator.of(context).pushNamed('/home');
            },
            splashColor: Colors    //هذا لما اضغط على المكان يصير لونه بالوف
                .deepPurple[200],
          ),

          ListTile(
            title: Text("تسجيل جديد"),
            onTap: () {
              Navigator.of(context).pushNamed('/login');
            },
            splashColor: Colors    //هذا لما اضغط على المكان يصير لونه بالوف
                .deepPurple[200],
          ),

          ListTile(
            title: Text("تسجيل دخول"),
            onTap: () {
              Navigator.of(context).pushNamed('/loginn');
            },
            splashColor: Colors    //هذا لما اضغط على المكان يصير لونه بالوف
                .deepPurple[200],
          ),
        ],
      ),
    );
  }
}
