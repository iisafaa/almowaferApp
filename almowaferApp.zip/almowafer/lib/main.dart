import 'package:almowafer/splash_screen/SplashScreen.dart';
import 'package:almowafer/splash_screen/Splash_screen2.dart';
import 'package:almowafer/splash_screen/introduction_screen.dart';
import 'package:almowafer/splash_screen/splashScreen3.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart'; // هذا الامبروت عشان نخلي المحاذاة من اليمين لليسار
import 'homepage/home_screen.dart';
import 'login_screen/login.dart';
import 'login_screen/signup.dart';
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      localizationsDelegates: [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: [
        Locale('ar', 'AE'), // نضيف اللغة الي نبغاها

      ],
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false,
      home:   IntroScreen(),
      routes: {
        '/home' : (context)=> HomeScreen(),
        '/login': (context)=> SignUp(),
        '/loginn': (context)=> loginScreen(),
        'welcom':  (context)=> loginScreen()

      },
    );
  }
}


//B767C6
