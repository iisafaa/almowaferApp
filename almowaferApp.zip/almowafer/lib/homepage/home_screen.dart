import 'package:flutter/material.dart';

import '../drawerscreen/drawer_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center( child : Image.asset('asset/almowaerlogo.png'))  ,
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 5,
      ),
        drawer: DrawerScreen(),
      body: Center(
        child: Text("تطبيق الموفر هو التطبيق الذي صممت واجهاته في التدريب الصيفي "
        ),
      ),
    );
  }
}
