import 'package:flutter/material.dart';


class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:   Center(
            child: Wrap(
              children:[ Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Image.asset('asset/Intro.png'),
                const SizedBox(
                    height: 25,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("مرحبًا بك",style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 30,
                        color: Color(0xff52307E),
                      ),),
                      Text("الموفر ",style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 30,
                        color: Color(0xffB767C6),
                      ),)

                    ],
                  ),
                  Text("وممكن تكون عضو في مجتمعنا\n          كمندوب توصيل.")

                ],
              ),
              ],
            ),
          ),



    );
  }
}
