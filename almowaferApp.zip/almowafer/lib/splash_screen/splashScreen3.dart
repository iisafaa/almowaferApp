import 'package:flutter/material.dart';

class SplashScreen3 extends StatefulWidget {
  const SplashScreen3({super.key});

  @override
  State<SplashScreen3> createState() => _SplashScreen3State();
}

class _SplashScreen3State extends State<SplashScreen3> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Wrap(
          children:[ Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Image.asset('asset/almowaerlogo.png'),


              Text("خليك نبيه"),

              const SizedBox(
                height: 50,
              ),
              ElevatedButton(onPressed: (){
                Navigator.of(context).pushNamed('/login');
              },
                child: Text("إبدأ", style:
                  TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.white
                  ),),
                style:ButtonStyle(

                  elevation: MaterialStateProperty.all(10),
                  backgroundColor: MaterialStateProperty.all(Color(0xff52307E)),  //لون خلفيه البوتون
                  padding: MaterialStateProperty.all((EdgeInsets.symmetric(horizontal: 70,vertical: 15))), // حجم البوتون
                  shape: MaterialStateProperty.all(RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)))
    ),


              )

            ],
          ),
          ],
        ),
      ),
    );
  }
}
